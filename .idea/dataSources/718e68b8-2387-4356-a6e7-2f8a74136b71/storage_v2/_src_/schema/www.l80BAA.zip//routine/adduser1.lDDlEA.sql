create function adduser1(username varchar(20))
  returns int unsigned
  BEGIN
INSERT goods_type (type_name) VALUES (username);
RETURN LAST_INSERT_ID();
END;

