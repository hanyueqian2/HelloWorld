create function f1()
  returns varchar(30)
  RETURN DATE_FORMAT(NOW(), '%Y年%m月%d日 %H时%i分%s秒');

