create procedure rrr(IN p_age smallint(5) unsigned, OUT remove_num int unsigned, OUT now_num int unsigned)
  BEGIN
SELECT COUNT(type_id) FROM goods_type WHERE parent_id = p_age INTO remove_num;
DELETE FROM goods_type WHERE parent_id = p_age;
SELECT COUNT(type_id) FROM goods_type INTO now_num;
END;

