create procedure sp1()
  SELECT VERSION();

