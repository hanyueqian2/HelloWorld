create procedure remove(IN p_id int unsigned)
  BEGIN
DELETE FROM text WHERE id = p_id;
END;

