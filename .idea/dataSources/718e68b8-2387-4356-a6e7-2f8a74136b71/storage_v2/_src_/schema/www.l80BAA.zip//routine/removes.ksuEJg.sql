create procedure removes(IN p_id int unsigned, OUT usernum int unsigned)
  BEGIN
DELETE FROM users WHERE id = p_id;
SELECT count(id) FROM users INTO usernum;
END;

